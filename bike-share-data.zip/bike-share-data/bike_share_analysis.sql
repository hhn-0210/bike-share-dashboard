-- This query stacks 2 tables, giving entries for 2 consecutive years
WITH bike_cte as (
SELECT * FROM bike_share_yr_0
UNION ALL
SELECT * FROM bike_share_yr_1)

-- Selecting columns relevant to business questions to return
SELECT dteday
season,
bcte.yr,
mnth,
weekday,
hr,
rider_type,
riders,
price,
COGS,
price*riders AS revenue,
price*riders - COGS AS profit
FROM bike_cte bcte
LEFT JOIN cost_table ct 
ON bcte.yr = ct.yr
